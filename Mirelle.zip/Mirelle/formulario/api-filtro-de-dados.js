// Selecionar o elemento de botão de busca
const searchButton = document.getElementById('search-button');

// Selecionar o elemento tbody da tabela

// Adicionar um evento de clique ao botão de busca
searchButton.addEventListener('click', () => {
    // Limpar a tabela antes de exibir os resultados da pesquisa anterior
    tbody.innerHTML = '';

    // Obter o valor inserido no campo de pesquisa
    const searchInput = document.getElementById('search-input');
    const nome = searchInput.value;

    // Fazer a chamada à API passando o nome como parâmetro
    axios.get(`http://localhost:7070/leitura-dados-alunos-nome?nome=${nome}`)
        .then(response => {
            // Obter os dados da resposta
            const alunos = response.data;

            // Iterar sobre os alunos e criar as linhas da tabela
            alunos.forEach(aluno => {
                // Criar uma nova linha na tabela
                const row = document.createElement('tr');

                // Preencher as células da linha com os dados do aluno
                const matriculaCell = document.createElement('td');
                matriculaCell.textContent = aluno.matricula;

                const nomeCell = document.createElement('td');
                nomeCell.textContent = aluno.nomealuno;


                const telefoneCell = document.createElement('td');
                telefoneCell.textContent = aluno.telefone;

                // Adicionar as células à linha
                row.appendChild(matriculaCell);
                row.appendChild(nomeCell);
                row.appendChild(telefoneCell);

                // Adicionar a linha ao tbody da tabela
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error(error);
        });
});

