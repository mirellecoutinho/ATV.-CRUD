// Função para enviar os dados do formulário para a API de cadastro
function enviarDadosAluno() {
    //Pegando elementos html
    const form = document.getElementById('form-escolar');
    const nomeInput = document.getElementById('nome');
    const dataNascInput = document.getElementById('dataNasc');
    const generoSelect = document.getElementById('genero');
    const serieInput = document.getElementById('serie');
    const turmaInput = document.getElementById('turma');
    const cidadeInput = document.getElementById('cidade');
    const estadoInput = document.getElementById('estado');
    const cepInput = document.getElementById('cep');
    const telefoneInput = document.getElementById('telefone');
    const emailInput = document.getElementById('email');

    //Recebendo valores do formulario html
    const nome = nomeInput.value;
    const dataNasc = moment(dataNascInput.value).format('YYYY-MM-DD');
    const genero = generoSelect.value;
    const serie = serieInput.value;
    const turma = turmaInput.value;
    const cidade = cidadeInput.value;
    const estado = estadoInput.value;
    const cep = cepInput.value;
    const telefone = telefoneInput.value;
    const email = emailInput.value;

    axios.post('http://localhost:7070/enviar-dados-alunos', {
        nome: nome,
        dataNasc: dataNasc,
        genero: genero,
        serie: serie,
        turma: turma,
        cidade: cidade,
        estado: estado,
        cep: cep,
        telefone: telefone,
        email: email
    })
        .then(response => {
            console.log(response.data);
            console.log(response)
            // Limpar os campos do formulário após o envio bem-sucedido
        
            form.reset();
        })
        .catch(error => {
            console.error(error);
        });
}

// Adicionar o evento de submit ao formulário
const form = document.getElementById('form-escolar');
form.addEventListener('submit', function (event) {
    event.preventDefault(); // Evitar que o formulário seja submetido normalmente
});

