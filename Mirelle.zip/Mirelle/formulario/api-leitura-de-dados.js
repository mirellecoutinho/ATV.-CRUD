// Selecionar o elemento tbody da tabela
const tbody = document.getElementById('pacientesTableBody');

// Fazer a requisição GET para a API
axios.get('http://localhost:7070/leitura-dados-alunos')
    .then(response => {
        // Obter os dados da resposta
        const alunos = response.data;

        // Iterar sobre os alunos e criar as linhas da tabela
        alunos.forEach(aluno => {
            // Criar uma nova linha na tabela
            const row = document.createElement('tr');

            // Preencher as células da linha com os dados do aluno
            const matriculaCell = document.createElement('td');
            matriculaCell.textContent = aluno.matricula;

            const nomeCell = document.createElement('td');
            nomeCell.textContent = aluno.nomealuno;

            const telefoneCell = document.createElement('td');
            telefoneCell.textContent = aluno.telefone;

            // Adicionar as células à linha
            row.appendChild(matriculaCell);
            row.appendChild(nomeCell);
            row.appendChild(telefoneCell);

            // Adicionar a linha ao tbody da tabela
            tbody.appendChild(row);
        });
    })
    .catch(error => {
        console.error(error);
    });






