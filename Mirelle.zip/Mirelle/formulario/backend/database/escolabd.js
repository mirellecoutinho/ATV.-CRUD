
const { Sequelize } = require("sequelize")

const bdescola = new Sequelize(
    'bdescola',        //usernameBD
    'root',           //rootName
    '1234',         //password BD
{
    host: 'localhost',
    dialect: 'mysql',
    logging: false
})

module.exports = bdescola