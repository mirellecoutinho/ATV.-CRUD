//Importacoes
const express = require("express")
const router = express()
const cors = require("cors")
const Aluno = require("./database/Aluno")
const { Op } = require("sequelize");


router.use(cors())
router.use(express.json())



router.post("/enviar-dados-alunos", (req, res) => {
    const { nome, dataNasc, genero, serie, turma, cidade, estado, cep, telefone, email } = req.body;

    console.log(nome, dataNasc, genero, serie, turma, cidade, estado, cep, telefone, email);


    Aluno.create({
        nomealuno: nome,
        genero: genero,
        serie: serie,
        turma: turma,
        telefone: telefone,
        dataNasc: dataNasc,
        email: email,
        uf: estado,
        cidade: cidade
    }).then((formulariodecadastro) => {
        console.log(formulariodecadastro.toJSON()); // Linha para limpeza de Dados
        res.send("Dados recebidos com sucesso!");
    });
})

router.get('/leitura-dados-alunos', (req, res) => {
    Aluno.findAll()
        .then(alunos => {
            res.json(alunos);
        })
        .catch(error => {
            console.error(error);
        });
});

router.get('/leitura-dados-alunos-nome', (req, res) => {
    const nome = req.query.nome; // Obtém o parâmetro 'nome' da URL

    // Verifica se o parâmetro 'nome' foi fornecido
    if (nome) {
        Aluno.findAll({
            where: {
                nomealuno: {
                    [Op.like]: `%${nome}%` // Utiliza o operador 'like' para buscar nomes que contenham a string fornecida
                }
            }
        })
            .then(alunos => {
                res.json(alunos);
            })
            .catch(error => {
                console.error(error);
                res.status(500).json({ error: 'Erro ao pesquisar alunos por nome.' });
            });
    } else {
        // Caso o parâmetro 'nome' não tenha sido fornecido, retorna todos os alunos
        Aluno.findAll()
            .then(alunos => {
                res.json(alunos);
            })
            .catch(error => {
                console.error(error);
                res.status(500).json({ error: 'Erro ao buscar alunos.' });
            });
    }
});


router.put("/atualizar-aluno/:matricula", (req, res) => {

    const matricula = req.params.matricula;
    const nome = req.body.nome;
    const dataNasc = req.body.dataNasc;
    const genero = req.body.genero;
    const serie = req.body.serie;
    const turma = req.body.turma;
    const cidade = req.body.cidade;
    const estado = req.body.estado;
    const telefone = req.body.telefone;
    const email = req.body.email;

    Aluno.update({
        nomealuno: nome,
        genero: genero,
        serie: serie,
        turma: turma,
        telefone: telefone,
        dataNasc: dataNasc,
        email: email,
        uf: estado,
        cidade: cidade
    }, {
        where: {
            matricula: matricula
        }
    }).then(() => {
        res.send("Dados do aluno atualizados com sucesso!");
    }).catch(() => {
        res.status(500).send("Ocorreu um erro ao atualizar os dados do aluno.");
    });
});

router.delete("/deletar-aluno/:matricula", (req, res) => {
    const matricula = req.params.matricula;

    Aluno.destroy({
        where: {
            matricula: matricula
        }
    }).then(() => {
        res.send("Aluno deletado!");
    }).catch(() => {
        res.status(500).send("Ocorreu um erro ao deletar o aluno.");
    });
});


const port = 7070;


//Porta do servidor
router.listen(7070, () => {
    console.log("Aplicação on-line!");
    console.log(`Rodando na porta: http://localhost:${port}`);

})      