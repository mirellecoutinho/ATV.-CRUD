/*var cacheName = 'pwaTeste+-v1.2';
*/


self.addEventListener('install', event => {

    self.skipWaiting();

    event.waitUntil(
        caches.open(cacheName)
            .then(cache => cache.addAll([

                './index.html',
                './assets/css',
                './assets/icons/escola 512.png',
                './assets/icons/escola 256.png',
                './assets/icons/escola 192.png',
                './assets/icons/escola 180.png',
                './assets/icons/escola 167.png',
                './assets/icons/escola 152.png',
                './assets/icons/escola 144.png',
                './assets/icons/escola 128.png',
                



            ]))
    );
});

self.addEventListener('message', function (event) {
    if (event.data.action === 'skipWaiting') {
        self.skipWaiting();
    }
});

self.addEventListener('fetch', function (event) {
    //Atualizacao internet
    event.respondWith(async function () {
        try {
            return await fetch(event.request);
        } catch (err) {
            return caches.match(event.request);
        }
    }());

    //Atualizacao cache
    /*event.respondWith(
      caches.match(event.request)
        .then(function (response) {
          if (response) {
            return response;
          }
          return fetch(event.request);
        })
    );*/

});